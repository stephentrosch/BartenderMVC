﻿CREATE TABLE [dbo].[Drinks]
(
	[ID] INT NOT NULL PRIMARY KEY,
	[DrinkName] TEXT NOT NULL,
	[Price] MONEY NOT NULL,
	[Quantity] INT NOT NULL,
	[TimeReceived] DATETIME NOT NULL
)
