﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using Bartender.Models;

namespace Bartender.Controllers
{
    public class DrinksController : Controller
    {
        private DrinkDBContext db = new DrinkDBContext();

        // GET: /Drink/
        public ActionResult Index(string DrinkName, string searchString)
        {
            var GenreLst = new List<string>();

            var GenreQry = from d in db.Drinks
                           orderby d.DrinkName
                           select d.DrinkName;

            GenreLst.AddRange(GenreQry.Distinct());
            //ViewBag.movieGenre = new SelectList(GenreLst);

            var drink = from m in db.Drinks
                         select m;

            if (!String.IsNullOrEmpty(searchString))
            {
                drink = drink.Where(s => s.DrinkName.Contains(searchString));
            }

            if (!string.IsNullOrEmpty(DrinkName))
            {
                drink = drink.Where(x => x.DrinkName == DrinkName);
            }

            return View(drink);
        }

        /*
MovieDBContext db = new MovieDBContext();
Movie movie = new Movie();
movie.Title = "Gone with the Wind";
db.Movies.Add(movie);
db.SaveChanges();        // <= Will throw server side validation exception
         * */

        // GET: /Movies/Details/5
public ActionResult Details(int? id)
{
    if (id == null)
    {
        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
    }
    Drink drink = db.Drinks.Find(id);
    if (drink == null)
    {
        return HttpNotFound();
    }
    return View(drink);
}

        // GET: /Movies/Create
        public ActionResult Create()
        {
            return View(new Drink
            {
                DrinkName = "Cosmopolitan",
                Price = 3.99M,
                TimeReceived= DateTime.Now,
                Quantity = 1,
            });
        }
        /*
public ActionResult Create()
{
    return View();
}

 */
// POST: /Movies/Create
// To protect from overposting attacks, please enable the specific properties you want to bind to, for
// more details see http://go.microsoft.com/fwlink/?LinkId=317598.
[HttpPost]
[ValidateAntiForgeryToken]
public ActionResult Create([Bind(Include = "ID,Title,ReleaseDate,Genre,Price,Rating")] Drink drink)
{
    if (ModelState.IsValid)
    {
        db.Drinks.Add(drink);
        db.SaveChanges();
        return RedirectToAction("Index");
    }

    return View(drink);
}

// GET: /Movies/Edit/5
public ActionResult Edit(int? id)
{
    if (id == null)
    {
        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
    }
    Drink drink = db.Drinks.Find(id);
    if (drink == null)
    {
        return HttpNotFound();
    }
    return View(drink);
}

// POST: /Movies/Edit/5
// To protect from overposting attacks, please enable the specific properties you want to bind to, for
// more details see http://go.microsoft.com/fwlink/?LinkId=317598.
[HttpPost]
[ValidateAntiForgeryToken]
public ActionResult Edit([Bind(Include = "ID,DrinkName,Price,TimeReceived,Quantity")] Drink drink)
{
    if (ModelState.IsValid)
    {
        db.Entry(drink).State = EntityState.Modified;
        db.SaveChanges();
        return RedirectToAction("Index");
    }
    return View(drink);
}


public ActionResult Delete(int? id)
{
    if (id == null)
    {
        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
    }
    Drink drink = db.Drinks.Find(id);
    if (drink == null)
    {
        return HttpNotFound();
    }
    return View(drink);
}

// POST: /Movies/Delete/5
[HttpPost, ActionName("Delete")]
[ValidateAntiForgeryToken]
public ActionResult DeleteConfirmed(int id)
{
    Drink drink = db.Drinks.Find(id);
    db.Drinks.Remove(drink);
    db.SaveChanges();
    return RedirectToAction("Index");
}

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
