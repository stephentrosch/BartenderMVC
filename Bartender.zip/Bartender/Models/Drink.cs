﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;

namespace Bartender.Models
{
    public class Drink
    {
        public int ID { get; set; }

        [StringLength(60, MinimumLength = 3)]
        public string DrinkName { get; set; }

        [Display(Name = "Time Order was Received")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime TimeReceived { get; set; }

        [Range(1, 100)]
        [DataType(DataType.Currency)]
        public decimal Price { get; set; }

        public int Quantity { get; set; }
    }

    public class DrinkDBContext : DbContext
    {
        public DrinkDBContext()
        {
            Database.SetInitializer<DrinkDBContext>
                (new MigrateDatabaseToLatestVersion<DrinkDBContext,
                    Bartender.Migrations.Configuration>());
        }
        public DbSet<Drink> Drinks { get; set; }
    }
}
